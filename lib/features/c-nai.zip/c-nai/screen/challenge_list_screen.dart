import 'package:amal_tracker/features/_challenge/provider/challenge_provider.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../widgets/challenge_card.dart';
import 'challenge_detail_screen.dart';
import 'package:amal_tracker/core/theme/app_color_tokens.dart';

class ChallengeListScreen extends ConsumerWidget {
  const ChallengeListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final challenges = ref.watch(activeChallengesProvider);

    return Scaffold(
      backgroundColor: context.colors.pageBg,
      appBar: AppBar(
        backgroundColor: context.colors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        title: Text('চ্যালেঞ্জ',
            style: TextStyle(
                color: context.colors.textPri,
                fontWeight: FontWeight.w800,
                fontSize: 18)),
      ),
      body: RefreshIndicator(
        color: context.colors.darkGreen,
        onRefresh: () => ref.refresh(activeChallengesProvider.future),
        child: challenges.when(
          loading: () => ListView(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
            children: const [
              ChallengeCardSkeleton(),
              ChallengeCardSkeleton(),
              ChallengeCardSkeleton(),
            ],
          ),
          error: (e, _) => _ErrorState(
              onRetry: () => ref.invalidate(activeChallengesProvider)),
          data: (list) {
            if (list.isEmpty) return const _EmptyState();

            // // Joined ones first (progress এ engaged থাকা challenge গুলো আগে
            // // দেখানো হয়, তারপর নতুন/অসম্পন্ন)
            // final sorted = [...list]..sort((a, b) {
            //     if (a.isJoined != b.isJoined) return a.isJoined ? -1 : 1;
            //     if (a.isJoined &&
            //         b.isJoined &&
            //         a.isCompleted != b.isCompleted) {
            //       return a.isCompleted ? 1 : -1;
            //     }
            //     return a.endDate.compareTo(b.endDate);
            //   });

            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final c = list[i];
                return ChallengeCard(
                  challenge: c,
                  index: i,
                  onTap: () {
                    HapticFeedback.selectionClick();
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => ChallengeDetailScreen(challengeId: c.id),
                    ));
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(top: 90),
      children: [
        Column(children: [
          const Text('🏆', style: TextStyle(fontSize: 46)),
          const SizedBox(height: 12),
          Text('এই মুহূর্তে কোনো চ্যালেঞ্জ নেই',
              style: TextStyle(
                  color: context.colors.textPri,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
          const SizedBox(height: 4),
          Text('শীঘ্রই নতুন চ্যালেঞ্জ যুক্ত হবে',
              style: TextStyle(color: context.colors.textSec2, fontSize: 12)),
        ]).animate().fadeIn(duration: 300.ms),
      ],
    );
  }
}

class _ErrorState extends StatelessWidget {
  final VoidCallback onRetry;
  const _ErrorState({required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(top: 90),
      children: [
        Column(children: [
          Icon(Icons.wifi_off_rounded,
              size: 40, color: context.colors.textHint),
          const SizedBox(height: 10),
          Text('লোড করা যায়নি',
              style: TextStyle(
                  color: context.colors.textPri,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
          const SizedBox(height: 10),
          Center(
            child: TextButton(
              onPressed: onRetry,
              child: Text('আবার চেষ্টা করুন',
                  style: TextStyle(
                      color: context.colors.darkGreen,
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
      ],
    );
  }
}
