import 'package:amal_tracker/core/theme/app_color_tokens.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:amal_tracker/features/_challenge/model/challenge_model.dart';
import 'package:amal_tracker/features/_challenge/provider/challenge_provider.dart';
import 'package:amal_tracker/features/_challenge/widgets/challenge_leaderboard_row.dart';
// ─────────────────────────────────────────────────────────────────────────
// NOTE FOR ABDULLAH: this file came through as 0 bytes in the .rar (same
// extraction error as challenge_card.dart). Rebuilt from scratch, wired to
// the leaderboardProvider(challengeId) / LeaderboardState you already have
// in challenge_provider.dart — full pagination (loadMore on scroll),
// pull-to-refresh, and the same LeaderboardRow used in the detail-screen
// preview so both places look identical.
//
// `currentUserId` isn't being passed in yet — the existing preview section
// in challenge_detail_screen.dart doesn't pass it either, so I kept the
// same behaviour rather than guessing at an auth-provider name. Wire in
// whatever provider holds the logged-in user's id and pass it down to get
// the "আপনি" highlight working here too.
// ─────────────────────────────────────────────────────────────────────────

class ChallengeLeaderboardScreen extends ConsumerStatefulWidget {
  final Challenge challenge;
  final String? currentUserId;
  const ChallengeLeaderboardScreen({
    super.key,
    required this.challenge,
    this.currentUserId,
  });

  @override
  ConsumerState<ChallengeLeaderboardScreen> createState() =>
      _ChallengeLeaderboardScreenState();
}

class _ChallengeLeaderboardScreenState
    extends ConsumerState<ChallengeLeaderboardScreen> {
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >
        _scrollController.position.maxScrollExtent - 200) {
      ref.read(leaderboardProvider(widget.challenge.id).notifier).loadMore();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(leaderboardProvider(widget.challenge.id));

    return Scaffold(
      backgroundColor: context.colors.pageBg,
      appBar: AppBar(
        backgroundColor: context.colors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('লিডারবোর্ড',
                style: TextStyle(
                    color: context.colors.textPri,
                    fontWeight: FontWeight.w800,
                    fontSize: 16)),
            Text(widget.challenge.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style:
                    TextStyle(color: context.colors.textSec2, fontSize: 11.5)),
          ],
        ),
      ),
      body: _buildBody(state),
    );
  }

  Widget _buildBody(LeaderboardState state) {
    if (state.isLoading && state.entries.isEmpty) {
      return ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: 8,
        itemBuilder: (_, __) => const LeaderboardRowSkeleton(),
      );
    }

    if (state.error != null && state.entries.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.wifi_off_rounded,
              size: 40, color: context.colors.textHint),
          const SizedBox(height: 10),
          Text('লোড করা যায়নি',
              style: TextStyle(
                  color: context.colors.textPri, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          TextButton(
            onPressed: () => ref
                .read(leaderboardProvider(widget.challenge.id).notifier)
                .refresh(),
            child: Text('আবার চেষ্টা করুন',
                style: TextStyle(
                    color: context.colors.darkGreen,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
      );
    }

    if (state.entries.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('🏁', style: TextStyle(fontSize: 42)),
          const SizedBox(height: 10),
          Text('এখনো কেউ অংশ নেননি',
              style: TextStyle(
                  color: context.colors.textPri, fontWeight: FontWeight.w700)),
        ]),
      );
    }

    return RefreshIndicator(
      color: context.colors.darkGreen,
      onRefresh: () =>
          ref.read(leaderboardProvider(widget.challenge.id).notifier).refresh(),
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.only(bottom: 20),
        itemCount: state.entries.length + (state.hasMore ? 1 : 0),
        itemBuilder: (_, i) {
          if (i >= state.entries.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 18),
              child: Center(
                  child: SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4))),
            );
          }
          final entry = state.entries[i];
          return LeaderboardRow(
            entry: entry,
            index: i,
            currentUserId: widget.currentUserId,
            isTop3RowStyle: true,
          );
        },
      ),
    );
  }
}
