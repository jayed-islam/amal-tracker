import 'package:amal_tracker/features/_challenge/model/challenge_model.dart';
import 'package:amal_tracker/features/_challenge/provider/challenge_provider.dart';
import 'package:amal_tracker/features/_challenge/widgets/challenge_colors.dart';
import 'package:amal_tracker/features/_challenge/widgets/challenge_leaderboard_row.dart';
import 'package:amal_tracker/features/_challenge/widgets/challenge_update_progress_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'challenge_leaderboard_screen.dart';

import 'package:amal_tracker/core/theme/app_color_tokens.dart';

class ChallengeDetailScreen extends ConsumerWidget {
  final String challengeId;
  const ChallengeDetailScreen({super.key, required this.challengeId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final challengeAsync = ref.watch(challengeDetailProvider(challengeId));

    return Scaffold(
      backgroundColor: context.colors.pageBg,
      appBar: AppBar(
        backgroundColor: context.colors.pageBg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: challengeAsync.whenOrNull(
              data: (c) => Text(c.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: context.colors.textPri,
                      fontWeight: FontWeight.w800,
                      fontSize: 15)),
            ) ??
            const SizedBox.shrink(),
        actions: [
          challengeAsync.whenOrNull(
                data: (c) => c.isJoined
                    ? PopupMenuButton<String>(
                        icon: Icon(Icons.more_vert_rounded,
                            color: context.colors.textPri),
                        onSelected: (v) {
                          if (v == 'leave') _confirmLeave(context, ref, c);
                        },
                        itemBuilder: (_) => [
                          PopupMenuItem(
                              value: 'leave',
                              child: Text('চ্যালেঞ্জ ছেড়ে দিন',
                                  style: TextStyle(color: context.colors.red))),
                        ],
                      )
                    : const SizedBox.shrink(),
              ) ??
              const SizedBox.shrink(),
          const SizedBox(width: 6),
        ],
      ),
      body: challengeAsync.when(
        loading: () => const _DetailSkeleton(),
        error: (e, _) => Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.wifi_off_rounded,
                size: 40, color: context.colors.textHint),
            const SizedBox(height: 10),
            Text('লোড করা যায়নি',
                style: TextStyle(color: context.colors.textPri)),
            TextButton(
              onPressed: () =>
                  ref.invalidate(challengeDetailProvider(challengeId)),
              child: const Text('আবার চেষ্টা করুন'),
            ),
          ]),
        ),
        data: (c) => RefreshIndicator(
          color: context.colors.darkGreen,
          onRefresh: () async {
            ref.invalidate(challengeDetailProvider(challengeId));
            if (c.isJoined) ref.invalidate(myProgressProvider(challengeId));
            await ref.read(challengeDetailProvider(challengeId).future);
          },
          child: ListView(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 30),
            children: [
              _HeroSection(challenge: c).animate().fadeIn(duration: 260.ms),
              const SizedBox(height: 14),
              if (c.isJoined) ...[
                _MyStatsSection(challengeId: challengeId)
                    .animate()
                    .fadeIn(delay: 60.ms, duration: 260.ms),
                const SizedBox(height: 14),
              ],
              _LeaderboardPreviewSection(challengeId: challengeId, challenge: c)
                  .animate()
                  .fadeIn(delay: 100.ms, duration: 260.ms),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmLeave(BuildContext context, WidgetRef ref, Challenge c) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: context.colors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('চ্যালেঞ্জ ছাড়বেন?',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        content: Text(
            'আপনার এখন পর্যন্ত ${c.myProgress?.currentValue ?? 0} ${c.unit} অগ্রগতি মুছে যাবে। এটি ফিরিয়ে আনা যাবে না।',
            style: TextStyle(color: context.colors.textSec2, fontSize: 13)),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('বাতিল',
                  style: TextStyle(color: context.colors.textSec2))),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              final ok = await ref
                  .read(challengeActionProvider(c.id).notifier)
                  .leave();
              if (context.mounted && ok) {
                Navigator.of(context).maybePop();
              }
            },
            child: Text('ছেড়ে দিন',
                style: TextStyle(
                    color: context.colors.red, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────
// HERO SECTION
// ─────────────────────────────────────────────────────────────────────────

class _HeroSection extends ConsumerWidget {
  final Challenge challenge;
  const _HeroSection({required this.challenge});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = challenge;
    final actionState = ref.watch(challengeActionProvider(c.id));
    final acting = actionState.isLoading;
    final pct = c.myProgress?.progressPercent ?? 0;

    return Container(
      decoration: BoxDecoration(
          color: context.colors.darkGreen,
          borderRadius: BorderRadius.circular(18)),
      child: Stack(children: [
        Positioned(
            top: -30,
            right: -30,
            child: Container(
                width: 100,
                height: 100,
                decoration: const BoxDecoration(
                    shape: BoxShape.circle, color: Color(0x08FFFFFF)))),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12)),
                  child: Icon(
                      c.isQuranChallenge
                          ? Icons.menu_book_rounded
                          : Icons.emoji_events_rounded,
                      color: context.colors.gold,
                      size: 21),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c.title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 17,
                              letterSpacing: -0.3)),
                      const SizedBox(height: 2),
                      Row(children: [
                        Icon(Icons.people_alt_rounded,
                            size: 11, color: Colors.white.withOpacity(0.5)),
                        const SizedBox(width: 4),
                        Text('${c.participantCount} জন অংশগ্রহণকারী',
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.55),
                                fontSize: 10.5)),
                      ]),
                    ],
                  ),
                ),
              ]),
              if (c.description != null && c.description!.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(c.description!,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.75),
                        fontSize: 12.5,
                        height: 1.45)),
              ],
              const SizedBox(height: 14),
              Row(children: [
                _statChip('${c.targetValue}', 'লক্ষ্য (${c.unit})'),
                const SizedBox(width: 10),
                _statChip(c.hasEnded ? 'শেষ' : '${c.daysLeft}',
                    c.hasEnded ? '' : 'দিন বাকি'),
                if (c.isJoined) ...[
                  const SizedBox(width: 10),
                  _statChip('$pct%', 'সম্পন্ন'),
                ],
              ]),
              const SizedBox(height: 14),
              if (c.isJoined) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(99),
                  child: LinearProgressIndicator(
                    value: (pct / 100).clamp(0.0, 1.0),
                    minHeight: 8,
                    backgroundColor: Colors.white.withOpacity(0.12),
                    valueColor: AlwaysStoppedAnimation(c.isCompleted
                        ? context.colors.gold
                        : context.colors.green),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                    '${c.myProgress?.currentValue ?? 0}/${c.targetValue} ${c.unit}',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.55), fontSize: 10.5)),
                const SizedBox(height: 12),
                if (c.isCompleted)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                        color: context.colors.gold.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(
                            color: context.colors.gold.withOpacity(0.4))),
                    child: Center(
                        child: Text('🎉 চ্যালেঞ্জ সম্পন্ন হয়েছে',
                            style: TextStyle(
                                color: context.colors.gold,
                                fontWeight: FontWeight.w800,
                                fontSize: 13))),
                  )
                else
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: acting || c.hasEnded
                          ? null
                          : () {
                              HapticFeedback.selectionClick();
                              showUpdateProgressSheet(context, c);
                            },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: context.colors.gold,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(11)),
                      ),
                      child: Text(c.hasEnded ? 'সময়সীমা শেষ' : 'আপডেট করুন',
                          style: TextStyle(
                              color: context.colors.darkGreen,
                              fontWeight: FontWeight.w800,
                              fontSize: 14)),
                    ),
                  ),
              ] else
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: (!c.isJoinable || acting)
                        ? null
                        : () async {
                            HapticFeedback.selectionClick();
                            await ref
                                .read(challengeActionProvider(c.id).notifier)
                                .join();
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: context.colors.gold,
                      disabledBackgroundColor: Colors.white.withOpacity(0.15),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(11)),
                    ),
                    child: acting
                        ? SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: context.colors.darkGreen))
                        : Text(
                            c.hasEnded
                                ? 'সময়সীমা শেষ হয়েছে'
                                : !c.hasStarted
                                    ? 'শীঘ্রই শুরু হবে'
                                    : 'চ্যালেঞ্জে যোগ দিন',
                            style: TextStyle(
                                color: context.colors.darkGreen,
                                fontWeight: FontWeight.w800,
                                fontSize: 14),
                          ),
                  ),
                ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _statChip(String value, String label) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 9),
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10)),
          child: Column(children: [
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 15)),
            if (label.isNotEmpty) ...[
              const SizedBox(height: 1),
              Text(label,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 8.5)),
            ],
          ]),
        ),
      );
}

// ─────────────────────────────────────────────────────────────────────────
// MY STATS SECTION — rank, daily needed, current pace
// ─────────────────────────────────────────────────────────────────────────

class _MyStatsSection extends ConsumerWidget {
  final String challengeId;
  const _MyStatsSection({required this.challengeId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final myProgress = ref.watch(myProgressProvider(challengeId));

    return myProgress.when(
      loading: () => const _StatsSkeleton(),
      error: (_, __) => const SizedBox.shrink(),
      data: (p) {
        if (p.isCompleted) return const SizedBox.shrink();
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: context.colors.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: context.colors.border, width: 0.5)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Text('📊', style: TextStyle(fontSize: 13)),
                const SizedBox(width: 6),
                Text('আপনার অগ্রগতি',
                    style: TextStyle(
                        color: context.colors.textPri,
                        fontWeight: FontWeight.w800,
                        fontSize: 13)),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                      color: context.colors.greenLight,
                      borderRadius: BorderRadius.circular(99)),
                  child: Text('র‍্যাংক #${p.rank}',
                      style: TextStyle(
                          color: context.colors.darkGreen,
                          fontSize: 10,
                          fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                _miniStat('${p.dailyNeeded}', 'দৈনিক প্রয়োজন', context),
                _divider(context),
                _miniStat('${p.currentDailyAvg}', 'বর্তমান গড়/দিন', context),
                _divider(context),
                _miniStat('${p.remaining}', 'বাকি আছে', context),
              ]),
              if (p.currentSurahNumber != null) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                      color: context.colors.purpleLight,
                      borderRadius: BorderRadius.circular(9)),
                  child: Row(children: [
                    Icon(Icons.bookmark_rounded,
                        size: 14, color: context.colors.purple),
                    const SizedBox(width: 6),
                    Text(
                        'বর্তমান অবস্থান: সূরা ${p.currentSurahNumber}, আয়াত ${p.currentAyahInSurah ?? 0}',
                        style: TextStyle(
                            color: context.colors.purple,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600)),
                  ]),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _divider(BuildContext context) => Container(
      width: 1,
      height: 32,
      color: context.colors.border,
      margin: const EdgeInsets.symmetric(horizontal: 6));

  Widget _miniStat(String value, String label, BuildContext context) =>
      Expanded(
        child: Column(children: [
          Text(value,
              style: TextStyle(
                  color: context.colors.textPri,
                  fontWeight: FontWeight.w800,
                  fontSize: 16)),
          const SizedBox(height: 2),
          Text(label,
              textAlign: TextAlign.center,
              style: TextStyle(color: context.colors.textHint, fontSize: 9)),
        ]),
      );
}

class _StatsSkeleton extends StatelessWidget {
  const _StatsSkeleton();
  @override
  Widget build(BuildContext context) => ChShimmer(
        child: Container(
          height: 100,
          decoration: BoxDecoration(
              color: context.colors.card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: context.colors.border, width: 0.5)),
        ),
      );
}

// ─────────────────────────────────────────────────────────────────────────
// LEADERBOARD PREVIEW
// ─────────────────────────────────────────────────────────────────────────

class _LeaderboardPreviewSection extends ConsumerWidget {
  final String challengeId;
  final Challenge challenge;
  const _LeaderboardPreviewSection(
      {required this.challengeId, required this.challenge});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final preview =
        ref.watch(leaderboardPreviewForChallengeProvider(challengeId));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Text('🏆', style: TextStyle(fontSize: 13)),
          const SizedBox(width: 6),
          Text('শীর্ষ তালিকা',
              style: TextStyle(
                  color: context.colors.textPri,
                  fontWeight: FontWeight.w800,
                  fontSize: 13)),
          const Spacer(),
          GestureDetector(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => ChallengeLeaderboardScreen(challenge: challenge),
            )),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                  color: context.colors.greenLight,
                  borderRadius: BorderRadius.circular(99)),
              child: Text('সব দেখুন →',
                  style: TextStyle(
                      color: context.colors.darkGreen,
                      fontSize: 10,
                      fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
        const SizedBox(height: 10),
        preview.when(
          loading: () => Container(
            decoration: BoxDecoration(
                color: context.colors.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: context.colors.border, width: 0.5)),
            child: const Column(children: [
              LeaderboardRowSkeleton(),
              LeaderboardRowSkeleton(),
              LeaderboardRowSkeleton(),
            ]),
          ),
          error: (_, __) => const SizedBox.shrink(),
          data: (entries) {
            if (entries.isEmpty) {
              return Container(
                height: 70,
                decoration: BoxDecoration(
                    color: context.colors.card,
                    borderRadius: BorderRadius.circular(14),
                    border:
                        Border.all(color: context.colors.border, width: 0.5)),
                child: Center(
                    child: Text('এখনো কেউ অংশ নেননি',
                        style: TextStyle(
                            color: context.colors.textHint, fontSize: 12.5))),
              );
            }
            return ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Container(
                decoration: BoxDecoration(
                    color: context.colors.card,
                    border:
                        Border.all(color: context.colors.border, width: 0.5)),
                child: Column(
                  children: entries
                      .asMap()
                      .entries
                      .map((e) => LeaderboardRow(entry: e.value, index: e.key))
                      .toList(),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _DetailSkeleton extends StatelessWidget {
  const _DetailSkeleton();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 30),
      children: [
        ChShimmer(
          child: Container(
              height: 260,
              decoration: BoxDecoration(
                  color: context.colors.darkGreen.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(18))),
        ),
        const SizedBox(height: 14),
        const _StatsSkeleton(),
      ],
    );
  }
}
