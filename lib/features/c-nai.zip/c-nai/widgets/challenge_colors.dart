import 'package:amal_tracker/core/theme/app_color_tokens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

// ─────────────────────────────────────────────────────────────────────────
// Challenge feature no longer keeps its own ChColors palette. Every color
// here now comes from context.colors (the single shared, dark/light-aware
// source of truth for the whole app — see core/theme/app_color_tokens.dart).
// This file only keeps the small reusable helpers (shimmer, skeleton bone,
// rank color/emoji) that the challenge screens share.
// ─────────────────────────────────────────────────────────────────────────

class ChShimmer extends StatelessWidget {
  final Widget child;
  const ChShimmer({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return child.animate(onPlay: (c) => c.repeat()).shimmer(
      duration: 1300.ms,
      colors: [
        Colors.transparent,
        Colors.white.withOpacity(0.55),
        Colors.transparent,
      ],
    );
  }
}

class ChBone extends StatelessWidget {
  final double width;
  final double height;
  final double radius;
  final Color? color;
  const ChBone({
    super.key,
    required this.width,
    required this.height,
    this.radius = 6,
    this.color,
  });

  @override
  Widget build(BuildContext context) => Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
            color: color ?? context.colors.skelBase,
            borderRadius: BorderRadius.circular(radius)),
      );
}

Color rankColor(BuildContext context, int rank) {
  switch (rank) {
    case 1:
      return context.colors.rankGold;
    case 2:
      return context.colors.rankSilver;
    case 3:
      return context.colors.rankBronze;
    default:
      return context.colors.midGreen;
  }
}

String rankEmoji(int rank) {
  switch (rank) {
    case 1:
      return '🥇';
    case 2:
      return '🥈';
    case 3:
      return '🥉';
    default:
      return '';
  }
}
