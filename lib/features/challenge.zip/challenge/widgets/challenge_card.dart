import 'package:amal_tracker/core/theme/app_color_tokens.dart';
import 'package:amal_tracker/features/challenge/model/challenge_model.dart';
import 'package:amal_tracker/features/challenge/widgets/challenge_colors.dart';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

// ─────────────────────────────────────────────────────────────────────────
// CHALLENGE CARD
//
// NOTE FOR ABDULLAH: the original widgets/challenge_card.dart came through
// as a 0-byte file in the .rar (extraction reported "Attempted to read more
// data than was available" for this file and challenge_leaderboard_screen.dart
// — both are corrupted in the archive, not something I can recover). This is
// a fresh implementation built to match the exact API your other challenge
// files already call it with (`ChallengeCard({challenge, index, onTap})`,
// `ChallengeCardSkeleton()`), plus a compact `ChallengeHomeTeaser` for the
// home screen slot you asked for. If your original had specific details
// I'm not matching, tell me what to change — this is a starting point, not
// a guess I'm attached to.
// ─────────────────────────────────────────────────────────────────────────

class ChallengeCard extends StatelessWidget {
  final Challenge challenge;
  final int index;
  final VoidCallback onTap;
  const ChallengeCard({
    super.key,
    required this.challenge,
    required this.onTap,
    this.index = 0,
  });

  @override
  Widget build(BuildContext context) {
    final c = challenge;
    final pct = c.myProgress?.progressPercent ?? 0;
    final accent =
        c.isQuranChallenge ? context.colors.gold : context.colors.midGreen;
    final accentBg = c.isQuranChallenge
        ? context.colors.amberLight
        : context.colors.greenLight;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: context.colors.card,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: context.colors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: accentBg,
                          borderRadius: BorderRadius.circular(12)),
                      child: Icon(
                          c.isQuranChallenge
                              ? Icons.menu_book_rounded
                              : Icons.flag_rounded,
                          color: accent,
                          size: 22),
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(c.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: context.colors.textPri,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14)),
                          const SizedBox(height: 3),
                          Text(_metaLine(c),
                              style: TextStyle(
                                  color: context.colors.textSec2,
                                  fontSize: 11.5)),
                        ],
                      ),
                    ),
                    if (c.isJoined && c.isCompleted)
                      const Text('✅', style: TextStyle(fontSize: 18))
                    else if (!c.isJoined)
                      _JoinPill(color: accent),
                  ],
                ),
                if (c.isJoined) ...[
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      value: (pct / 100).clamp(0, 1).toDouble(),
                      minHeight: 7,
                      backgroundColor: context.colors.skelBase,
                      valueColor: AlwaysStoppedAnimation(accent),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('$pct% সম্পন্ন',
                          style: TextStyle(
                              color: accent,
                              fontWeight: FontWeight.w700,
                              fontSize: 11)),
                      Text('${c.daysLeft} দিন বাকি',
                          style: TextStyle(
                              color: context.colors.textHint, fontSize: 11)),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    )
        .animate()
        .fadeIn(delay: Duration(milliseconds: index * 40))
        .slideY(begin: 0.04, end: 0, delay: Duration(milliseconds: index * 40));
  }

  String _metaLine(Challenge c) {
    final target = '${c.targetValue} ${c.unit}';
    final people = '${c.participantCount} জন';
    if (!c.isJoined) return '$target · $people অংশ নিয়েছেন';
    return '${c.myProgress?.currentValue ?? 0}/${c.targetValue} ${c.unit} · ${c.daysLeft} দিন বাকি';
  }
}

class _JoinPill extends StatelessWidget {
  final Color color;
  const _JoinPill({required this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(99)),
        child: const Text('যোগ দিন',
            style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700)),
      );
}

class ChallengeCardSkeleton extends StatelessWidget {
  const ChallengeCardSkeleton({super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: ChShimmer(
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: context.colors.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: context.colors.border),
            ),
            child: Row(children: [
              ChBone(
                  width: 44,
                  height: 44,
                  radius: 12,
                  color: context.colors.skelBaseDark),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ChBone(
                        width: 140,
                        height: 13,
                        color: context.colors.skelBaseDark),
                    const SizedBox(height: 7),
                    ChBone(
                        width: 90,
                        height: 10,
                        color: context.colors.skelBaseDark),
                  ],
                ),
              ),
            ]),
          ),
        ),
      );
}

// ─────────────────────────────────────────────────────────────────────────
// HOME-SCREEN TEASER — a single compact instance for the home screen, per
// your request ("challenge er akta instance home page a o thakbe"). Sits
// next to your other home cards (hero, weekly chart, ayah cards, etc).
// Shows the user's most relevant challenge: their most-progressed active
// one if joined, otherwise the newest joinable one. Tapping opens the list.
// ─────────────────────────────────────────────────────────────────────────

class ChallengeHomeTeaser extends StatelessWidget {
  final Challenge challenge;
  final int? totalActiveCount;
  final VoidCallback onTap;
  const ChallengeHomeTeaser({
    super.key,
    required this.challenge,
    required this.onTap,
    this.totalActiveCount,
  });

  @override
  Widget build(BuildContext context) {
    final c = challenge;
    final pct = c.myProgress?.progressPercent ?? 0;
    final accent =
        c.isQuranChallenge ? context.colors.gold : context.colors.midGreen;

    return Material(
      color: context.colors.darkGreen,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16)),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(11)),
                child: Icon(
                    c.isQuranChallenge
                        ? Icons.menu_book_rounded
                        : Icons.emoji_events_rounded,
                    color: Colors.white,
                    size: 20),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text('চ্যালেঞ্জ',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.65),
                              fontSize: 10.5,
                              fontWeight: FontWeight.w600)),
                      if ((totalActiveCount ?? 0) > 1) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.14),
                              borderRadius: BorderRadius.circular(99)),
                          child: Text('+${totalActiveCount! - 1} আরও',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ]),
                    const SizedBox(height: 2),
                    Text(c.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5)),
                    const SizedBox(height: 6),
                    if (c.isJoined)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(
                          value: (pct / 100).clamp(0, 1).toDouble(),
                          minHeight: 6,
                          backgroundColor: Colors.white.withOpacity(0.16),
                          valueColor:
                              const AlwaysStoppedAnimation(Colors.white),
                        ),
                      )
                    else
                      Text(
                          '${c.participantCount} জন অংশ নিয়েছেন · ${c.daysLeft} দিন বাকি',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.75),
                              fontSize: 10.5)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded,
                  color: Colors.white.withOpacity(0.7), size: 20),
            ],
          ),
        ),
      ),
    ).animate().fadeIn(duration: 260.ms);
  }
}

class ChallengeHomeTeaserSkeleton extends StatelessWidget {
  const ChallengeHomeTeaserSkeleton({super.key});
  @override
  Widget build(BuildContext context) => ChShimmer(
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: context.colors.skelBase,
              borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            ChBone(
                width: 40,
                height: 40,
                radius: 11,
                color: context.colors.skelBaseDark),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ChBone(
                      width: 110,
                      height: 12,
                      color: context.colors.skelBaseDark),
                  const SizedBox(height: 8),
                  ChBone(
                      width: 160,
                      height: 8,
                      color: context.colors.skelBaseDark),
                ],
              ),
            ),
          ]),
        ),
      );
}
