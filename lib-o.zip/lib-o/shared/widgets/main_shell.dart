// import 'package:amal_tracker/features/notification/widgets/notification_widgets.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:amal_tracker/core/providers/connectivity_provider.dart';
// import 'package:amal_tracker/features/home/screens/home_screen.dart';

// import 'package:amal_tracker/features/leaderboard/screens/leaderboard_screen.dart';
// import 'package:amal_tracker/features/tracker/screens/monthly_view_screen.dart';
// import 'package:amal_tracker/features/tracker/screens/tracker_screen.dart';
// import 'package:amal_tracker/shared/widgets/offline_banner.dart';

// // ── Tab index constants — magic numbers ──────────────────────
// enum AppTab {
//   home,
//   tracker,
//   monthly,
//   leaderboard,
//   // jannahGarden,
// }

// class MainShell extends ConsumerStatefulWidget {
//   const MainShell({super.key});

//   @override
//   ConsumerState<MainShell> createState() => _MainShellState();
// }

// class _MainShellState extends ConsumerState<MainShell> {
//   AppTab _activeTab = AppTab.home;

//   // ── visitedTabs tracks which tabs have been opened at least once.
//   // IndexedStack keeps every child alive, but we only BUILD a tab's
//   // widget the first time the user taps it — this avoids unnecessary
//   // API calls on startup (lazy initialisation, same as Instagram/Grab).
//   final Set<AppTab> _visitedTabs = {AppTab.home};

//   void _onTabTap(AppTab tab) {
//     if (_activeTab == tab) {
//       // Same tab tapped again → notify the tab to scroll to top.
//       // Each screen listens to this notifier and scrolls if it has a list.
//       tabScrollToTopNotifier.value = tab;
//       return;
//     }
//     setState(() {
//       _activeTab = tab;
//       _visitedTabs.add(tab); // mark as visited so IndexedStack builds it
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     // ── Connectivity listener: online snackbar ─────────────────────────
//     ref.listen<bool>(isOnlineProvider, (previous, next) {
//       if (previous == false && next == true) {
//         ScaffoldMessenger.of(context).clearSnackBars();
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(
//             content: const Row(
//               children: [
//                 Icon(Icons.wifi_rounded, color: Colors.white, size: 16),
//                 SizedBox(width: 8),
//                 Text(
//                   'সংযোগ পুনরুদ্ধার হয়েছে',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontWeight: FontWeight.w600,
//                     fontSize: 13,
//                   ),
//                 ),
//               ],
//             ),
//             backgroundColor: context.colors.green,
//             behavior: SnackBarBehavior.floating,
//             duration: const Duration(seconds: 3),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//             margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
//           ),
//         );
//       }
//     });

//     return Scaffold(
//       // ── IndexedStack — industry standard for bottom nav ───────────────
//       //
//       // WHY IndexedStack:
//       //   • All visited tabs stay alive in memory (no API re-call on switch)
//       //   • Scroll position is preserved (intended UX — like Instagram)
//       //   • Unvisited tabs are NOT built yet (lazy loading)
//       //
//       // WHY NOT StatefulShellRoute.indexedStack:
//       //   • That's a GoRouter abstraction for deep-linking across tabs
//       //   • Adds complexity we don't need
//       //   • Tab UX is a UI concern, not a routing concern
//       //
//       body: IndexedStack(
//         index: _activeTab.index,
//         children: AppTab.values.map((tab) {
//           // Lazy: if tab hasn't been visited yet, render an empty box.
//           // Once visited, the real screen is built and kept alive forever.
//           if (!_visitedTabs.contains(tab)) return const SizedBox.shrink();

//           return switch (tab) {
//             AppTab.home => const HomeScreen(),
//             AppTab.tracker => const TrackerScreen(),
//             // Monthly and Leaderboard get a UniqueKey so they REBUILD
//             // every time the user visits — fresh data, no stale state.
//             // Home and Tracker preserve scroll/state like Instagram.
//             AppTab.monthly => MonthlyViewScreen(key: UniqueKey()),
//             AppTab.leaderboard => LeaderboardScreen(key: UniqueKey()),
//             // AppTab.jannahGarden => JannahWorldScreen(key: UniqueKey()),
//           };
//         }).toList(),
//       ),

//       // ── Bottom nav + offline banner ────────────────────────────────────
//       bottomNavigationBar: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           const OfflineBanner(),
//           _BottomNav(
//             activeTab: _activeTab,
//             onTap: _onTabTap,
//           ),
//         ],
//       ),
//     );
//   }
// }

// // ── Scroll-to-top notifier ─────────────────────────────────────────────────
// // When the user taps the active tab again, this fires.
// // Screens that want scroll-to-top behaviour listen to this.
// //
// // Usage inside HomeScreen (example):
// //   @override void initState() {
// //     super.initState();
// //     tabScrollToTopNotifier.addListener(_onScrollToTop);
// //   }
// //   void _onScrollToTop() {
// //     if (tabScrollToTopNotifier.value == AppTab.home) {
// //       _scrollController.animateTo(0, ...);
// //     }
// //   }
// final ValueNotifier<AppTab?> tabScrollToTopNotifier = ValueNotifier(null);

// // ── Bottom Navigation Bar ──────────────────────────────────────────────────
// class _BottomNav extends StatelessWidget {
//   final AppTab activeTab;
//   final void Function(AppTab) onTap;

//   const _BottomNav({required this.activeTab, required this.onTap});

//   static const _items = [
//     _NavItem(tab: AppTab.home, icon: Icons.home_rounded, label: 'হোম'),
//     _NavItem(
//         tab: AppTab.tracker, icon: Icons.list_alt_rounded, label: 'ট্র্যাকার'),
//     _NavItem(
//         tab: AppTab.monthly, icon: Icons.bar_chart_rounded, label: 'রিপোর্ট'),
//     _NavItem(
//         tab: AppTab.leaderboard,
//         icon: Icons.emoji_events_rounded,
//         label: 'র‍্যাংকিং'),
//     // _NavItem(
//     //   tab: AppTab.jannahGarden,
//     //   icon: Icons.park_rounded,
//     //   label: 'জান্নাত',
//     // ),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       decoration: const BoxDecoration(
//         color: context.colors.card,
//         border: Border(top: BorderSide(color: context.colors.border, width: 0.5)),
//       ),
//       child: SafeArea(
//         top: false,
//         child: Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: _items.map((item) {
//               final active = item.tab == activeTab;
//               return GestureDetector(
//                 onTap: () => onTap(item.tab),
//                 behavior: HitTestBehavior.opaque,
//                 child: AnimatedContainer(
//                   duration: const Duration(milliseconds: 200),
//                   curve: Curves.easeInOut,
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 16,
//                     vertical: 7,
//                   ),
//                   decoration: BoxDecoration(
//                     color: active ? context.colors.greenLight : Colors.transparent,
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Column(
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       AnimatedSwitcher(
//                         duration: const Duration(milliseconds: 200),
//                         child: Icon(
//                           item.icon,
//                           key: ValueKey(active),
//                           size: 22,
//                           color:
//                               active ? context.colors.avatar1 : context.colors.textMuted,
//                         ),
//                       ),
//                       const SizedBox(height: 3),
//                       Text(
//                         item.label,
//                         style: TextStyle(
//                           color:
//                               active ? context.colors.avatar1 : context.colors.textMuted,
//                           fontSize: 9,
//                           fontWeight:
//                               active ? FontWeight.w700 : FontWeight.w500,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               );
//             }).toList(),
//           ),
//         ),
//       ),
//     );
//   }
// }

// class _NavItem {
//   final AppTab tab;
//   final IconData icon;
//   final String label;
//   const _NavItem({
//     required this.tab,
//     required this.icon,
//     required this.label,
//   });
// }
import 'package:amal_tracker/core/providers/connectivity_provider.dart';
import 'package:amal_tracker/features/notification/widgets/notification_widgets.dart';
import 'package:amal_tracker/shared/widgets/offline_banner.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/providers/cache_provider.dart';
import 'package:amal_tracker/core/theme/app_color_tokens.dart';

class MainShell extends ConsumerStatefulWidget {
  final StatefulNavigationShell navigationShell;
  const MainShell({super.key, required this.navigationShell});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> with WidgetsBindingObserver {
  StatefulNavigationShell get _shell => widget.navigationShell;
  DateTime? _lastBackPress;

  // GoRouter delegate listen করবো — route বদলালে rebuild হবে
  late final GoRouterDelegate _delegate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _delegate = GoRouter.of(context).routerDelegate;
    _delegate.addListener(_onRouteChanged);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _delegate.removeListener(_onRouteChanged);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ref.read(cacheStatusProvider.notifier).checkTtlAndMarkDirty();
    }
  }

  void _onRouteChanged() {
    if (mounted) setState(() {});
  }

  void _onTabTap(int index) {
    ref.read(activeTabIndexProvider.notifier).state = index;
    _shell.goBranch(
      index,
      initialLocation: index == _shell.currentIndex,
    );
  }

  Future<void> _onPopInvoked(bool didPop) async {
    if (didPop) return;

    final router = GoRouter.of(context);

    // Case 1: stack এ page আছে → pop
    if (router.canPop()) {
      router.pop();
      return;
    }

    // Case 2: Home tab এ নেই → Home এ যাও
    if (_shell.currentIndex != 0) {
      _shell.goBranch(0, initialLocation: true);
      return;
    }

    // Case 3: Home root → double back to exit
    final now = DateTime.now();
    final isDoubleBack = _lastBackPress != null &&
        now.difference(_lastBackPress!) < const Duration(seconds: 2);

    if (isDoubleBack) {
      SystemNavigator.pop();
      return;
    }

    _lastBackPress = now;
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: const Text(
            'আবার back চাপলে অ্যাপ বন্ধ হবে',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w500,
              fontSize: 13,
            ),
          ),
          backgroundColor: context.colors.avatar1,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    // Sync active index provider with the current shell tab index
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        final currentActive = ref.read(activeTabIndexProvider);
        if (currentActive != _shell.currentIndex) {
          ref.read(activeTabIndexProvider.notifier).state = _shell.currentIndex;
        }
      }
    });

    ref.listen<bool>(isOnlineProvider, (previous, next) {
      if (previous == false && next == true) {
        ScaffoldMessenger.of(context)
          ..clearSnackBars()
          ..showSnackBar(
            SnackBar(
              content: const Row(
                children: [
                  Icon(Icons.wifi_rounded, color: Colors.white, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'সংযোগ পুনরুদ্ধার হয়েছে',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
              backgroundColor: context.colors.green,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 3),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            ),
          );
      }
    });

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) => _onPopInvoked(didPop),
      child: Scaffold(
        body: _shell,
        bottomNavigationBar: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const OfflineBanner(),
            _BottomNav(
              activeIndex: _shell.currentIndex,
              onTap: _onTabTap,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Bottom Navigation Bar ──────────────────────────────────────────────────
class _BottomNav extends StatelessWidget {
  final int activeIndex;
  final void Function(int) onTap;

  const _BottomNav({required this.activeIndex, required this.onTap});

  static const _items = [
    _NavItem(icon: Icons.home_rounded, label: 'হোম'),
    _NavItem(icon: Icons.list_alt_rounded, label: 'ট্র্যাকার'),
    _NavItem(icon: Icons.bar_chart_rounded, label: 'রিপোর্ট'),
    _NavItem(icon: Icons.emoji_events_rounded, label: 'র‍্যাংকিং'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: context.colors.card,
        border: Border(top: BorderSide(color: context.colors.border, width: 0.5)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(_items.length, (index) {
              final item = _items[index];
              final active = index == activeIndex;
              return GestureDetector(
                onTap: () => onTap(index),
                behavior: HitTestBehavior.opaque,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeInOut,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: active ? context.colors.greenLight : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 200),
                        child: Icon(
                          item.icon,
                          key: ValueKey(active),
                          size: 22,
                          color:
                              active ? context.colors.avatar1 : context.colors.textMuted,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        item.label,
                        style: TextStyle(
                          color:
                              active ? context.colors.avatar1 : context.colors.textMuted,
                          fontSize: 9,
                          fontWeight:
                              active ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}
